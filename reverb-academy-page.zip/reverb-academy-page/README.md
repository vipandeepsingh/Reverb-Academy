# Reverb Academy Page

Standalone HTML landing page for Reverb Academy.

Open `index.html` in a browser, or host the folder on GitHub Pages / Netlify / Vercel as a static site.

The booking button opens WhatsApp for `+91 7707991919`.
